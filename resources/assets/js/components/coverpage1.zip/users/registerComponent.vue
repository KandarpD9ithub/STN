<template>
	<div class="inner_home_bg">
		<div class="container">
			<div class="inner_home">
				<div class="col-sm-12 col-xs-12 col-md-12 col-lg-12">
					<nav class="navbar">
						<div class="navbar-header">
						  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span> 
						  </button>
						</div>
						<div class="collapse navbar-collapse" id="myNavbar">
						  <ul class="nav navbar-nav">
							<li><a href="profile.html">MAGAZINE <b> PROFILE </b></a></li>
							<li><a href="library.html">MY <b> LIBRARY </b></a></li>
							<li><a href="step1.html">MY <b> CUSTOMIZED PAGES</b></a></li>
							<li><a href="#">FAQ</a></li>
						  </ul>
						</div>
					</nav>
				</div>
				<div class="col-sm-12 col-xs-12 col-md-12 col-lg-12 home_content">
					<div class="form_profile">
						<h3>John Q. Smith of ABC Travel</h3>
						<form class="profile_form">
							<div class=" col-sm-12 col-md-12 col-xs-12">
								<div class="form-group">
									<div class=" col-sm-4 col-md-4 col-xs-12">
										<input type="type" class="form-control" placeholder="Agent Name">
									</div>
									<div class="  col-sm-4 col-md-4 col-xs-12">
										<input type="type" class="form-control" placeholder="Company Name">
									</div>
									<div class="  col-sm-4 col-md-4 col-xs-12">
										<input type="type" class="form-control" placeholder="Email">
									</div>
								</div>
							</div>
							<div class=" col-sm-12 col-md-12 col-xs-12">
								<div class="form-group">
									<div class="  col-sm-4 col-md-4 col-xs-12">
										<input type="type" class="form-control" placeholder="Address">
									</div>
									<div class="  col-sm-4 col-md-4 col-xs-12">
										<input type="type" class="form-control" placeholder="Address">
									</div>
									<div class="  col-sm-4 col-md-4 col-xs-12">
										<input type="type" class="form-control" placeholder="URL">
									</div>
								</div>
							</div>
							<div class=" col-sm-12 col-md-12 col-xs-12">
								<div class="form-group">
									<div class="  col-sm-4 col-md-4 col-xs-12">
										<select class="form-control">
											<option value="1">City</option>
										</select>
									</div>
									<div class="  col-sm-4 col-md-4 col-xs-12">
										<div class="row">
											<div class=" col-sm-6 col-md-4 col-xs-6">
												<select class="form-control">
													<option value="1">State</option>
												</select>
											</div>
											<div class=" col-sm-6 col-md-8 col-xs-6">
												<input type="type" class="form-control zip_code" placeholder="Zip Code">
											</div>
										</div>
									</div>
									<div class=" col-sm-4 col-md-4 col-xs-12">
										<input type="type" class="form-control" placeholder="CST#">
									</div>
								</div>
							</div>
							<div class=" col-sm-12 col-md-12 col-xs-12">
								<div class="form-group">
									<div class="  col-sm-4 col-md-4 col-xs-12">
										<input type="type" class="form-control" placeholder="Direct Number ">
									</div>
									<div class="  col-sm-4 col-md-4 col-xs-12">
										<input type="type" class="form-control" placeholder="Office Number">
									</div>
									<div class="  col-sm-4 col-md-4 col-xs-12">
										<input type="type" class="form-control" placeholder="Fax Number">
									</div>
								</div>
							</div>
							<div class=" col-sm-12 col-md-12 col-xs-12">
								<div class="form-group">
									<div class=" col-sm-4 col-md-4 col-xs-12 pull-right">
										<input type="submit" class="submit_btn"  value="Save">
									</div>
								</div>
							</div>
						</form>
					</div>
 				</div>
			</div>
		</div>
	</div>
</template>

<<script>
    export default {
            date() {
                return {
                    
                }
            }
    }
</script>
